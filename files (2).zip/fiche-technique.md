# Fiche technique : Patrimmo

| | |
|---|---|
| **Projet** | Gestion du patrimoine immobilier de l’État |
| **Nom de la solution** | Patrimmo |
| **Version** | 1.0 |
| **Auteure** | KAKPOVI Dela Nadia |
| **Période** | 10 au 15 novembre 2026 |
| **Dépôt** | https://github.com/kakpovidela0509-cyber/Gestion_de_patrimoine |

## 1. Objectif

Remplacer les registres papier par une plateforme web centralisée pour enregistrer les biens immobiliers de l’État, tracer leurs affectations, organiser les inventaires, suivre la maintenance et produire des rapports.

## 2. Périmètre

- **Inclus :** biens immobiliers (bâtiments administratifs, logements de fonction, entrepôts, locaux techniques).
- **Exclus de la version 1 :** mobilier, matériel, terrains non bâtis.

## 3. Choix techniques et justification

| Composant | Choix | Raison |
|---|---|---|
| Langage et framework | PHP 8.2, Laravel 12 | Imposé par le cahier des charges ; validation, ORM et sécurité intégrés |
| Base de données | PostgreSQL 16 | Imposé ; robuste et adaptée aux données relationnelles |
| Authentification | Laravel Sanctum (jetons) | Simple, intégré à Laravel, adapté à une API |
| Conteneurisation | Docker, Docker Compose | Imposé ; déploiement identique sur toute machine |
| Interface | HTML, CSS, JavaScript natif | Léger, sans étape de compilation, servi par la passerelle |
| Conception | UML (Mermaid), Figma | Diagrammes versionnés dans le dépôt ; maquettes sur Figma |

## 4. Architecture

Architecture en **microservices** : quatre applications Laravel indépendantes, chacune avec sa propre base de données, derrière une passerelle unique.

| Service | Port | Responsabilité | Base |
|---|---|---|---|
| `gateway` | 8000 (Docker : 8080) | Interface web, redirection des appels vers les services | `gateway_db` |
| `auth-service` | 8001 | Connexion, jetons, comptes, rôles | `auth_db` |
| `patrimoine-service` | 8002 | Biens, services, mouvements, maintenance, statistiques | `patrimoine_db` |
| `inventaire-service` | 8003 | Campagnes d’inventaire, constats, rapports | `inventaire_db` |
| `postgres` | 5432 | Instance PostgreSQL unique, quatre bases | n/a |

Principes retenus :

- **Une base par service** : aucune table partagée ; les services échangent par API REST (JSON).
- **Point d’entrée unique** : le navigateur ne parle qu’à la passerelle.
- **Vérification du jeton centralisée** : chaque service interroge `GET /api/me` du service Auth, puis contrôle le rôle.
- **Indépendance** : un service peut être modifié, redéployé ou ajouté (par exemple un service « Mobilier ») sans toucher aux autres.

## 5. Sécurité

- Mots de passe hachés (bcrypt) ; jetons d’accès Sanctum.
- Contrôle d’accès par rôle sur chaque route sensible (administrateur, gestionnaire, responsable, contrôleur, direction).
- Validation de toutes les données côté serveur ; échappement du contenu affiché dans l’interface.
- Secrets dans `.env`, exclu du dépôt ; `APP_DEBUG=false` en production.
- Aucune suppression définitive des biens : archivage et historique des mouvements.

## 6. Conteneurisation

- Un `Dockerfile` par service (image `php:8.2-cli`, extensions `pdo_pgsql` et `zip`, Composer).
- `docker-compose.yml` : un conteneur PostgreSQL avec **volume persistant**, un conteneur par service, un réseau commun, vérification de l’état de la base avant le démarrage des services.
- Au démarrage, chaque service applique ses migrations ; Auth crée l’administrateur par défaut et Patrimoine les services de l’administration.
- Le script `db/init/01-create-databases.sh` crée les quatre bases au premier lancement.

## 7. Variables d’environnement

`APP_ENV`, `APP_DEBUG`, `APP_KEY`, `DB_USER`, `DB_PASSWORD`, `JWT_SECRET` (fichier `.env`), et les adresses `AUTH_SERVICE_URL`, `PATRIMOINE_SERVICE_URL`, `INVENTAIRE_SERVICE_URL` définies dans `docker-compose.yml`.

## 8. Prérequis

| Mode | Prérequis |
|---|---|
| Docker | Docker Desktop ou Docker Engine avec Compose |
| Développement sans Docker | PHP 8.2+, Composer |

Configuration minimale conseillée pour un hébergement : 2 vCPU, 2 Go de RAM, 10 Go de disque.

## 9. Vérifications réalisées

- Chaque service testé séparément, sans Docker (`php artisan serve`, base SQLite) : connexion, contrôle des rôles, création et liste de biens, campagnes d’inventaire, rapports.
- Communication entre services testée (vérification du jeton, lecture des biens par le service Inventaire).
- Les `Dockerfile` et le `docker-compose.yml` sont fournis ; leur exécution complète est à valider sur la machine de déploiement.

## 10. Limites et évolutions

Limites : export CSV uniquement, pas de pièces jointes, pas de tests automatisés complets, pas de journal d’audit à l’écran.

Évolutions : mobilier et matériel, terrains non bâtis, export PDF, pièces jointes, notifications, amortissement, cartographie, journal d’audit, application mobile pour l’inventaire.
