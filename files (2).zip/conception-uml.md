# Conception UML : Patrimmo

Les diagrammes sont écrits en **Mermaid** : GitHub les affiche directement dans cette page.

## 1. Cas d’utilisation

```mermaid
flowchart LR
    ADM([Administrateur])
    GES([Gestionnaire])
    RES([Responsable de service])
    CON([Contrôleur])
    DIR([Direction])

    subgraph Patrimmo
        U1[Se connecter]
        U2[Gérer les comptes et les rôles]
        U3[Enregistrer et modifier un bien]
        U4[Consulter les biens et les fiches]
        U5[Demander une affectation, un transfert ou une sortie]
        U6[Valider ou refuser une demande]
        U7[Déclarer et suivre la maintenance]
        U8[Lancer et clôturer un inventaire]
        U9[Enregistrer un constat d’inventaire]
        U10[Produire et exporter les rapports]
    end

    ADM --- U1 & U2 & U3 & U5 & U6 & U7 & U8 & U9 & U10
    GES --- U1 & U3 & U4 & U5 & U7 & U8 & U9 & U10
    RES --- U1 & U4 & U5
    CON --- U1 & U4 & U9 & U10
    DIR --- U1 & U4 & U6 & U10
```

## 2. Diagramme de classes

```mermaid
classDiagram
    class User {
        +id
        +name
        +email
        +password
        +role
    }
    class Service {
        +id
        +nom
    }
    class Bien {
        +id
        +code
        +designation
        +type
        +adresse
        +superficie
        +date_acquisition
        +valeur
        +titre_propriete
        +etat
        +statut
    }
    class Mouvement {
        +id
        +type
        +motif
        +statut
        +demandeur_id
        +valide_par
    }
    class Maintenance {
        +id
        +nature
        +date_intervention
        +prestataire
        +cout
        +statut
    }
    class Inventaire {
        +id
        +libelle
        +annee
        +statut
    }
    class InventaireLigne {
        +id
        +constat
        +resultat
        +commentaire
    }

    Service "1" --> "*" Bien : est affectataire de
    Bien "1" --> "*" Mouvement : historique
    Bien "1" --> "*" Maintenance : interventions
    Inventaire "1" --> "*" InventaireLigne : contient
    Bien "1" ..> "*" InventaireLigne : constaté dans
    Mouvement "*" --> "0..1" Service : origine
    Mouvement "*" --> "0..1" Service : destination
    User "1" ..> "*" Mouvement : demande ou valide
```

Répartition en microservices : `User` appartient au service **Auth** ; `Service`, `Bien`, `Mouvement`, `Maintenance` au service **Patrimoine** ; `Inventaire` et `InventaireLigne` au service **Inventaire**. Les liens entre services passent par des identifiants (`demandeur_id`, `bien_id`), jamais par des clés étrangères entre bases.

## 3. Diagramme de séquence : affectation d’un bien avec validation

```mermaid
sequenceDiagram
    actor G as Gestionnaire
    actor D as Direction
    participant W as Gateway
    participant P as Service Patrimoine
    participant A as Service Auth

    G->>W: POST /api/patrimoine/mouvements
    W->>P: transmet la demande et le jeton
    P->>A: GET /api/me (jeton et rôle)
    A-->>P: utilisateur (rôle gestionnaire)
    P-->>W: mouvement "en attente"
    W-->>G: demande enregistrée

    D->>W: POST /api/patrimoine/mouvements/:id/valider
    W->>P: transmet la validation et le jeton
    P->>A: GET /api/me (jeton et rôle)
    A-->>P: utilisateur (rôle direction)
    P->>P: met à jour le service du bien
    P-->>W: mouvement "validé"
    W-->>D: demande validée
```

## 4. Diagramme de séquence : constat d’inventaire

```mermaid
sequenceDiagram
    actor C as Contrôleur
    participant W as Gateway
    participant I as Service Inventaire
    participant P as Service Patrimoine
    participant A as Service Auth

    C->>W: POST /api/inventaire/inventaires/:id/lignes
    W->>I: transmet le constat et le jeton
    I->>A: GET /api/me
    A-->>I: utilisateur autorisé
    I->>P: GET /api/biens/:bien_id
    P-->>I: code et désignation du bien
    I->>I: calcule le résultat (conforme, à vérifier, écart)
    I-->>W: constat enregistré
    W-->>C: confirmation
```

## 5. Diagramme d’activités : cycle de vie d’un bien

```mermaid
flowchart TD
    A([Début]) --> B[Enregistrer le bien]
    B --> C[Acquisition historisée]
    C --> D{Besoin ?}
    D -->|Affecter ou transférer| E[Demande soumise]
    E --> F{Direction}
    F -->|Valide| G[Service du bien mis à jour]
    F -->|Refuse| D
    G --> D
    D -->|Incident| H[Intervention de maintenance]
    H --> D
    D -->|Inventaire| I[Constat sur le terrain]
    I --> D
    D -->|Fin de vie| J[Demande de sortie]
    J --> K{Direction}
    K -->|Valide| L[Bien sorti du patrimoine]
    K -->|Refuse| D
    L --> M([Fin])
```

## 6. Diagrammes d’états

**Demande de mouvement :**

```mermaid
stateDiagram-v2
    [*] --> en_attente : demande soumise
    en_attente --> valide : validation
    en_attente --> refuse : refus
    valide --> [*]
    refuse --> [*]
```

**Bien immobilier :**

```mermaid
stateDiagram-v2
    [*] --> actif : enregistrement
    actif --> actif : affectation, transfert, maintenance, inventaire
    actif --> archive : archivage
    actif --> sorti : sortie validée
    archive --> [*]
    sorti --> [*]
```

## 7. Diagramme de composants et de déploiement

```mermaid
flowchart TB
    NAV[Navigateur]

    subgraph DOCKER[Hôte Docker : docker-compose.yml]
        GW[gateway<br/>Laravel + interface web<br/>port 8000]
        AU[auth-service<br/>Laravel<br/>port 8001]
        PA[patrimoine-service<br/>Laravel<br/>port 8002]
        IN[inventaire-service<br/>Laravel<br/>port 8003]
        subgraph PG[Conteneur PostgreSQL 16]
            DB1[(auth_db)]
            DB2[(patrimoine_db)]
            DB3[(inventaire_db)]
            DB4[(gateway_db)]
        end
    end

    NAV -->|HTTP| GW
    GW --> AU
    GW --> PA
    GW --> IN
    PA -->|vérification du jeton| AU
    IN -->|vérification du jeton| AU
    IN -->|lecture des biens| PA
    AU --> DB1
    PA --> DB2
    IN --> DB3
    GW --> DB4
```
