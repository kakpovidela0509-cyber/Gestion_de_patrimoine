# Proposition financière : Patrimmo

> **Hypothèses à valider.** Les montants ci-dessous sont **indicatifs** : ils reposent sur un tarif journalier supposé de **30 000 FCFA** et sur des tarifs d’hébergement estimés. Aucun budget de référence n’a été communiqué. Les chiffres peuvent être modifiés sans changer la structure du document.

## 1. Objet

Conception, développement, déploiement et documentation d’une plateforme de gestion du patrimoine immobilier de l’État (version 1), en architecture microservices.

## 2. Coût de réalisation

| Lot | Contenu | Charge (jours) | Montant (FCFA) |
|---|---|---:|---:|
| 1 | Analyse du besoin | 2 | 60 000 |
| 2 | Conception UML et maquettes Figma | 3 | 90 000 |
| 3 | Service Auth (connexion, comptes, rôles) | 2 | 60 000 |
| 4 | Service Patrimoine (biens, mouvements, maintenance) | 4 | 120 000 |
| 5 | Service Inventaire (campagnes, rapports) | 3 | 90 000 |
| 6 | Passerelle et interface web | 4 | 120 000 |
| 7 | Conteneurisation Docker et déploiement | 2 | 60 000 |
| 8 | Tests et recette | 2 | 60 000 |
| 9 | Documentation, guide d’utilisation et formation des agents | 2 | 60 000 |
| | **Total réalisation** | **24** | **720 000** |

## 3. Coûts récurrents (par an)

| Poste | Hypothèse | Montant annuel (FCFA) |
|---|---|---:|
| Hébergement (serveur 2 vCPU, 2 Go de RAM) | 15 000 FCFA par mois, à confirmer auprès de l’hébergeur | 180 000 |
| Nom de domaine et certificat HTTPS | forfait estimé | 15 000 |
| Sauvegardes de la base | incluses ou forfait estimé | 20 000 |
| Maintenance corrective et évolutive | 15 % du coût de réalisation | 108 000 |
| **Total annuel** | | **323 000** |

## 4. Synthèse

| | Montant (FCFA) |
|---|---:|
| Réalisation (une fois) | 720 000 |
| Première année d’exploitation | 323 000 |
| **Coût total de la première année** | **1 043 000** |
| Coût annuel à partir de la deuxième année | 323 000 |

## 5. Ce qui est inclus

- Application complète (quatre services et interface web), code source sur GitHub.
- Maquettes, conception UML, fiche technique, guide d’utilisation.
- Formation des agents (une journée, comprise dans le lot 9).
- Un mois de garantie après la mise en service : correction des anomalies sans frais.

## 6. Ce qui n’est pas inclus

- Patrimoine mobilier, matériel et terrains non bâtis (évolutions futures).
- Reprise des données des registres papier : saisie ou import à chiffrer selon le volume.
- Matériel informatique des utilisateurs et connexion Internet.

## 7. Planning indicatif

| Étape | Durée |
|---|---|
| Analyse et conception | 5 jours |
| Développement des services et de l’interface | 13 jours |
| Déploiement, tests et recette | 4 jours |
| Documentation et formation | 2 jours |

## 8. Conditions

- Validité de l’offre : 30 jours.
- Paiement proposé : 40 % à la commande, 40 % à la livraison, 20 % après la recette.
- Toute évolution hors périmètre fait l’objet d’un avenant chiffré.
