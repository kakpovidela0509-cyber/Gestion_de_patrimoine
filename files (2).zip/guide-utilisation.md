# Guide d’utilisation : Patrimmo

Ce guide explique comment utiliser Patrimmo, pas à pas, selon votre rôle.

## 1. Premiers pas

### Se connecter

1. Ouvrir l’adresse de la plateforme dans un navigateur (Chrome, Edge ou Firefox).
2. Saisir votre **adresse e-mail** et votre **mot de passe**.
3. Cliquer sur **Se connecter**.

Après la connexion, le **tableau de bord** s’affiche. Le menu de gauche permet d’accéder aux pages. Il affiche en bas votre nom et votre rôle.

> Compte administrateur de démonstration : `admin@patrimoine.tg` / `Admin@2026`. **Changez ce mot de passe dès la première utilisation** (créez votre propre compte administrateur, puis supprimez celui-ci).

### Se déconnecter

Cliquer sur **Se déconnecter**, en bas du menu. La session est aussi fermée si elle expire : il suffit de se reconnecter.

## 2. Ce que chaque rôle peut faire

| Rôle | Peut faire |
|---|---|
| **Administrateur** | Tout, y compris gérer les comptes |
| **Gestionnaire** | Gérer les biens, la maintenance et les inventaires ; demander des opérations |
| **Responsable de service** | Consulter ; demander une affectation, un transfert ou une sortie |
| **Contrôleur** | Consulter ; enregistrer des constats d’inventaire ; exporter les rapports |
| **Direction** | Consulter ; **valider ou refuser** les demandes ; exporter les rapports |

Les boutons que vous ne pouvez pas utiliser n’apparaissent pas.

## 3. Le tableau de bord

Il présente le nombre de biens, la superficie totale, le nombre de biens à réhabiliter, la répartition par type et les derniers mouvements.

## 4. Gérer les biens immobiliers

### Enregistrer un bien (administrateur, gestionnaire)

1. Menu **Biens immobiliers**, puis bouton **Nouveau bien**.
2. Remplir la **désignation**, le **type** et l’**adresse** (obligatoires), puis la superficie, la date d’acquisition, la valeur, le titre de propriété, l’état et le service affectataire.
3. Cliquer sur **Enregistrer**.

Le code d’inventaire (par exemple `IMM-0001`) est créé automatiquement.

### Rechercher un bien

Saisir un mot dans la barre de recherche (code ou désignation) puis appuyer sur **Entrée**, ou utiliser les filtres de type et d’état.

### Consulter la fiche d’un bien

Cliquer sur une ligne du tableau. La fiche montre les informations du bien, l’historique de ses mouvements et ses interventions de maintenance.

### Modifier ou archiver un bien (administrateur, gestionnaire)

Sur la fiche : **Modifier** pour corriger les informations, **Archiver** pour retirer le bien de la liste. Un bien n’est jamais supprimé : il reste dans l’historique.

## 5. Affecter, transférer ou sortir un bien

### Faire une demande (administrateur, gestionnaire, responsable)

1. Sur la fiche du bien : **Affecter**, **Transférer** ou **Proposer la sortie**. Ou page **Affectations**, bouton **Nouvelle opération**.
2. Choisir le **service destinataire** (sauf pour une sortie) et indiquer le **motif**.
3. Cliquer sur **Soumettre pour validation**.

La demande apparaît avec le statut **En attente**. Rien ne change tant qu’elle n’est pas validée.

### Valider ou refuser (Direction, administrateur)

1. Menu **Affectations**.
2. Repérer les demandes **En attente** (filtre « Tous les statuts »).
3. Cliquer sur **Valider** ou **Refuser**.

Après validation, le service du bien est mis à jour (ou le bien sort du patrimoine pour une sortie) et l’opération est inscrite dans l’historique.

## 6. Les inventaires

### Lancer une campagne (administrateur, gestionnaire)

1. Menu **Inventaires**, bouton **Lancer une campagne**.
2. Saisir le libellé et l’année, puis valider.

### Enregistrer un constat (administrateur, gestionnaire, contrôleur)

1. Ouvrir la campagne en cours.
2. Bouton **Enregistrer un constat**.
3. Choisir le bien et le constat :
   - **Présent, en bon état** : résultat *Conforme* ;
   - **Présent, dégradé** : résultat *À vérifier* ;
   - **Introuvable** : résultat *Écart*.
4. Ajouter un commentaire si besoin, puis enregistrer.

La barre d’**avancement** indique la part des biens déjà constatés. Un nouveau constat sur le même bien remplace le précédent.

### Clôturer (administrateur, gestionnaire)

Bouton **Clôturer** : plus aucun constat ne peut être ajouté à cette campagne.

## 7. La maintenance

1. Menu **Maintenance**, bouton **Déclarer un incident** (administrateur, gestionnaire).
2. Choisir le bien, décrire les travaux, ajouter la date, le prestataire et le coût estimé.
3. Quand les travaux sont faits, cliquer sur **Terminer** sur la ligne concernée.

## 8. Les rapports

1. Menu **Rapports**.
2. Pour chaque rapport : **Aperçu** pour le voir à l’écran, ou **Télécharger (Excel)** pour obtenir un fichier à ouvrir dans Excel.

Rapports disponibles : **Inventaire immobilier**, **Biens par service**, **Biens à réhabiliter**.

## 9. Gérer les utilisateurs (administrateur)

1. Menu **Utilisateurs**, bouton **Nouveau compte**.
2. Saisir le nom, l’e-mail, un mot de passe de 8 caractères minimum et le rôle.
3. Pour retirer un accès : bouton **Supprimer** sur la ligne (vous ne pouvez pas supprimer votre propre compte).

## 10. Questions fréquentes

| Problème | Solution |
|---|---|
| « Identifiants incorrects » | Vérifier l’e-mail et le mot de passe ; demander à l’administrateur de réinitialiser le compte. |
| « Accès refusé » | Votre rôle ne permet pas cette action ; contacter l’administrateur. |
| « Service indisponible » | Un des services est arrêté ou en cours de démarrage : attendre une minute puis recharger la page. |
| Le bouton « Valider » n’apparaît pas | Seuls la Direction et l’administrateur peuvent valider. |
| Impossible d’ajouter un constat | La campagne est clôturée : lancer une nouvelle campagne. |
| Le fichier Excel s’ouvre mal | Ouvrir Excel, puis **Données**, **À partir d’un fichier texte ou CSV**, encodage UTF-8, séparateur point-virgule. |

## 11. Bonnes pratiques

- Ne partagez jamais votre mot de passe.
- Renseignez toujours un **motif** clair pour une demande.
- Lancez une campagne d’inventaire au moins une fois par an.
- Déconnectez-vous sur un poste partagé.
